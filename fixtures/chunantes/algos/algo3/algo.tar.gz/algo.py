'''Submission example with sklearn'''
import logging
import json
import numpy as np
from sklearn.linear_model import SGDClassifier

import substratools as tools


# For now, logging will not be reported in Substra for security reasons
logging.basicConfig(filename='model/log_model.log', level=logging.DEBUG)


class Algo(tools.Algo):

    def dump_sklearn_model(self, model):
        attr = model.__dict__
        data = {
            key: value.tolist() if isinstance(value, np.ndarray) else value
            for key, value in attr.items()
            if key[-1] == '_' and key != 'loss_function_'
        }
        return data

    def load_sklearn_model(self, data):
        model = SGDClassifier(warm_start=True, loss='log', random_state=42)
        if data is not None:
            for key, value in data.items():
                if isinstance(value, list):
                    setattr(model, key, np.array(value))
                else:
                    setattr(model, key, value)
        return model

    def load_model(self, path):
        with open(path, 'r') as f:
            return json.load(f)

    def save_model(self, model, path):
        with open(path, 'w') as f:
            json.dump(model, f)

    def train(self, X, y, models, rank=0):
        # extract data
        logging.info('Getting data')
        X_train = X
        y_train = y
        # standardize data
        print(X)
        print(y)
        X_train = X_train.reshape(X_train.shape[0], -1)
        X_train = np.nan_to_num((X_train - np.mean(X_train, axis=0)) / np.std(X_train, axis=0))

        # fit model on data
        logging.info('Fitting model')

        model = models[0] if models else None
        clf = self.load_sklearn_model(model)
        clf.fit(X_train, y_train.argmax(axis=1))

        y_pred = clf.predict_proba(X_train)

        return y_pred, self.dump_sklearn_model(clf)

    def predict(self, X, model):
        X_test = X
        X_test = X_test.reshape(X_test.shape[0], -1)
        X_test = np.nan_to_num((X_test - np.mean(X_test, axis=0)) / np.std(X_test, axis=0))

        clf = self.load_sklearn_model(model)
        y_pred = clf.predict_proba(X_test)
        return y_pred


if __name__ == '__main__':
    tools.algo.execute(Algo())
