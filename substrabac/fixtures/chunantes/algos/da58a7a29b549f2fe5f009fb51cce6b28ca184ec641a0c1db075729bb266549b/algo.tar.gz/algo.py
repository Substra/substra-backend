'''Submission example with sklearn'''
import os
import json
import logging
import argparse
import numpy as np
from sklearn.linear_model import SGDClassifier

import opener

# For now, logging will not be reported in Substra for security reasons
logging.basicConfig(filename='model/log_model.log', level=logging.DEBUG)


class Model:
    '''Class for submitted algo/model derives from the SubstraModel class
    defined in substratools'''
    def __init__(self, data_folder='./data', pred_folder='./pred', model_folder='./model', inmodel_files=None, outmodel_file='model'):
        self.data_folder = data_folder
        self.pred_folder = pred_folder
        self.model_folder = model_folder
        self.inmodel_files = inmodel_files
        self.outmodel_file = outmodel_file

        self.clf = SGDClassifier(warm_start=True, loss='log', random_state=42)
        # check if existing estimated params and update model if it is the case
        try:
            self.load_json_sklearn(self.clf)
            logging.info('Model successfully loaded')
            print('Model successfully loaded')
        except FileNotFoundError:
            logging.info('No model found, use algo')

    def save_json_sklearn(self, model):
        '''Save estimated params of a sklearn model in a json file.
        Does not work for sklearn.ensemble estimators'''
        attr = model.__dict__
        estimated_params = {key: value.tolist() if isinstance(value, np.ndarray) else value
                            for key, value in attr.items() if key[-1] == '_' and key != 'loss_function_'}
        with open(os.path.join(self.model_folder, self.outmodel_file), 'w') as f:
            json.dump(estimated_params, f)

    def load_json_sklearn(self, model):
        ''' Load estimated params of a trained sklearn model from a json file'''
        if self.inmodel_files is not None:
            # Handle only one inmodel
            with open(os.path.join(self.model_folder, self.inmodel_files[0]), 'r') as f:
                attr = json.load(f)
            for key, value in attr.items():
                if isinstance(value, list):
                    setattr(model, key, np.array(value))
                else:
                    setattr(model, key, value)

    def train(self):
        # extract data
        logging.info('Getting data')
        X_train = opener.get_X(self.data_folder)
        y_train = opener.get_y(self.data_folder)
        # standardize data
        X_train = X_train.reshape(X_train.shape[0], -1)
        X_train = np.nan_to_num((X_train - np.mean(X_train, axis=0)) / np.std(X_train, axis=0))
        # fit model on data
        logging.info('Fitting model')
        self.clf.fit(X_train, y_train.argmax(axis=1))
        # save trained model -- DO NOT FORGET THIS STEP
        logging.info('Saving fitted model')
        self.save_json_sklearn(self.clf)
        # save prediction on train data in pred folder
        y_pred = self.clf.predict_proba(X_train)
        opener.save_pred(y_pred, self.pred_folder)

    def pred(self):
        # extract data and standardize
        X_test = opener.get_X(self.data_folder)
        X_test = X_test.reshape(X_test.shape[0], -1)
        X_test = np.nan_to_num((X_test - np.mean(X_test, axis=0)) / np.std(X_test, axis=0))
        # compute prediction on data
        y_pred = self.clf.predict_proba(X_test)
        # save prediction on test data in pred folder
        opener.save_pred(y_pred, self.pred_folder)

    def dry_run(self):
        # extract data
        logging.info('Getting data')
        X_train = opener.fake_X()
        y_train = opener.fake_y()
        # standardize data
        X_train = X_train.reshape(X_train.shape[0], -1)
        X_train = np.nan_to_num((X_train - np.mean(X_train, axis=0)) / np.std(X_train, axis=0))
        # fit model on data
        logging.info('Fitting model')
        self.clf.fit(X_train, y_train.argmax(axis=1))
        # save trained model -- DO NOT FORGET THIS STEP
        logging.info('Saving fitted model')
        self.save_json_sklearn(self.clf)
        # save prediction on train data in pred folder
        y_pred = self.clf.predict_proba(X_train)
        opener.save_pred(y_pred, self.pred_folder)


if __name__ == '__main__':

    parser = argparse.ArgumentParser()
    parser.add_argument('-d', '--dry-run', action='store_true', default=False,
                        help='Launch dry run')
    parser.add_argument('-t', '--train', action='store_true', default=False,
                        help='Launch train')
    parser.add_argument('-p', '--predict', action='store_true', default=False,
                        help='Launch train')
    parser.add_argument('-m', '--inmodels', metavar='TraintupleKey', type=str, nargs='+',
                        help='List of model traintuplekey')
    args = vars(parser.parse_args())

    if args['train']:
        logging.info('Starting train...')
        model = Model(inmodel_files=args['inmodels'])
        model.train()
    elif args['predict']:
        logging.info('Starting predict...')
        model = Model(inmodel_files=args['inmodels'])
        model.pred()
    elif args['dry_run']:
        logging.info('Starting dry run...')
        model = Model(inmodel_files=args['inmodels'])
        model.dry_run()
    else:
        raise ValueError('task not implemented, should be either train or predict')
